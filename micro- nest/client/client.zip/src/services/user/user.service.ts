import { Injectable,Inject } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { IUser } from 'src/interfaces/user.interface';

@Injectable()
export class UserService {

    constructor(@Inject('auth') private readonly authMicroservice: ClientProxy,
    @Inject('users') private readonly userMicroservice: ClientProxy){}
    async addUser(user:IUser){

        return await this.userMicroservice.send('useradd',user);
    }

    async updateUser(user:IUser){
     
    }

}
