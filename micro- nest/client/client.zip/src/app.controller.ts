import { Controller, Get,Post,Body,Put,Res, Req, Session, UseGuards } from '@nestjs/common';
import { Response,Request, response } from 'express';
import { UserService } from './services/user/user.service';
import { IUser } from './interfaces/user.interface';
import { AuthService } from './services/auth/auth.service';
import { UserDto } from './dtos/user.dto';
import { JoiPipe } from 'nestjs-joi/internal/joi.pipe';
import { ValidationPipe } from './validations/user.pipe';
@Controller('api')
export class AppController {
  constructor(private readonly userService: UserService,
              private readonly authService:AuthService
    ) {}

  @Post('user')
  addUser(@Body() user:IUser) {
    return this.userService.addUser(user)
  }
  @Put('/updateuser')
  updateUser(@Body() user:IUser){
    
  }


  @Post('/login')
  login(@Body() user:IUser ,@Req() request:Request,@Session() sessions : { views?: string }){

    const loginUser :any =this.authService.login(user);
    sessions.views=loginUser.users
    return loginUser;
    
  }


  @Post('/register')

 async register(@Body(new ValidationPipe()) user:UserDto ,@Req() request:Request,@Res({ passthrough: true }) response: Response){
    const loginUser:any=await this.authService.register(user);
    if(loginUser.token){
      response.cookie('token',loginUser.token)
      return loginUser.message
  
    }
    return loginUser
  }


  @Post('/logout')
  logOut(@Body() user:IUser, @Req() req:Request,@Res() response:Response){

   response.clearCookie('connect.sid')
   return response.status(200).json('you loged out')

  }
@Post('ex')
 async ex(@Body() user:IUser){
   return await this.userService.addUser(user)
  }
}
