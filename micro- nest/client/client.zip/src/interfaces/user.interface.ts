export interface IUser{
 Username:string,
 Email:string,
 Password:string,
 PhoneNumber:string
}